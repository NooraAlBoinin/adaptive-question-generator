# question_generator.py
from typing import Dict, List, Optional

import textstat

from langchain_openai import ChatOpenAI
from langchain_core.output_parsers import PydanticOutputParser
from pydantic import BaseModel, Field, validator
from textstat import textstat  # ✅ this is the correct import
import json


class QuestionSchema(BaseModel):
    """Pydantic model defining expected question structure."""
    question_stem: str = Field(..., min_length=10, max_length=500)
    correct_answer: str = Field(..., min_length=3, max_length=200)
    distractors: List[str] = Field(..., min_items=3, max_items=3)
    explanation: str = Field(..., min_length=20, max_length=1000)
    bloom_level: str = Field(..., pattern="^(Knowledge|Comprehension|Application|Analysis)$")
    estimated_difficulty: float = Field(..., ge=1.0, le=5.0)

    @validator('distractors')
    def check_distractor_lengths(cls, v):
        """Ensure distractors are similar length to avoid cueing."""
        lengths = [len(d) for d in v]
        if max(lengths) - min(lengths) > 50:
            raise ValueError("Distractors have inconsistent lengths")
        return v


class QuestionGenerator:
    """
    Generates curriculum-aligned MCQs using LLM prompting with
    few-shot learning and structured output parsing.
    """

    def __init__(self, api_key: str, model: str = "gpt-4-0613",
                 temperature: float = 0.7):
        self.llm = ChatOpenAI(
            model=model,
            temperature=temperature,
            openai_api_key=api_key,
            request_timeout=60
        )
        self.output_parser = PydanticOutputParser(pydantic_object=QuestionSchema)

        # Load few-shot exemplars
        self.exemplars = self._load_exemplars()

    def _load_exemplars(self) -> List[Dict]:
        """Load manually authored exemplar questions for few-shot learning."""
        return [
            {
                "learning_outcome": "Students will be able to identify strong passwords.",
                "grade_level": "3",
                "bloom_level": "Knowledge",
                "difficulty": "2",
                "question": {
                    "question_stem": "Which password is the strongest?",
                    "correct_answer": "MyDog#2024!",
                    "distractors": [
                        "password",
                        "12345678",
                        "mydog2024"
                    ],
                    "explanation": "MyDog#2024! is strongest because it combines uppercase letters, lowercase letters, numbers, and special characters, making it hard to guess.",
                    "bloom_level": "Knowledge",
                    "estimated_difficulty": 2.0
                }
            },
            {
                "learning_outcome": "Students will be able to explain why sharing personal information online can be risky.",
                "grade_level": "4",
                "bloom_level": "Comprehension",
                "difficulty": "3",
                "question": {
                    "question_stem": "Why should you not share your home address on social media?",
                    "correct_answer": "Strangers could find out where you live and visit without permission",
                    "distractors": [
                        "Your friends already know where you live",
                        "It takes too long to type your full address",
                        "Social media websites do not allow addresses"
                    ],
                    "explanation": "Sharing your home address online allows strangers to know where you live, which could be dangerous. Personal information should be kept private to protect your safety.",
                    "bloom_level": "Comprehension",
                    "estimated_difficulty": 3.0
                }
            },
            {
                "learning_outcome": "Students will be able to apply strategies to recognize phishing emails.",
                "grade_level": "5",
                "bloom_level": "Application",
                "difficulty": "4",
                "question": {
                    "question_stem": "You receive an email saying 'Your school account will be closed unless you click this link and enter your password.' What should you do?",
                    "correct_answer": "Delete the email and tell a teacher or parent about it",
                    "distractors": [
                        "Click the link immediately to save your account",
                        "Reply to the email asking if it is real",
                        "Forward the email to all your classmates"
                    ],
                    "explanation": "This is a phishing email trying to steal your password. Real organizations never ask for passwords via email. You should delete suspicious emails and report them to adults.",
                    "bloom_level": "Application",
                    "estimated_difficulty": 4.0
                }
            }
        ]

    def generate_question(
            self,
            learning_outcome: Dict,
            target_difficulty: str = "Medium",
            max_attempts: int = 3,
    ) -> Optional[Dict]:
        prompt = self._build_prompt(learning_outcome, target_difficulty=target_difficulty)

        for attempt in range(1, max_attempts + 1):
            try:
                response = self.llm.invoke(prompt)
                raw_output = getattr(response, "content", str(response))

                question = self.parser.parse(raw_output)

                if self._validate_question(question, learning_outcome):
                    return question.model_dump()
                else:
                    print(f"Generation attempt {attempt} failed validation.")
            except Exception as e:
                print(f"Generation attempt {attempt} failed: {e}")

        return None

    def _build_prompt(self, learning_outcome: Dict, target_difficulty: str = "Medium") -> str:

        """Construct prompt with system role, context, constraints, and examples."""

        # System role
        system_message = """You are an expert educational assessment designer specializing in digital literacy and cybersecurity education for primary school children in Qatar. Your questions must be age-appropriate, culturally sensitive, and aligned to curriculum learning outcomes."""

        # Context
        context = f"""
Target Grade Level: Grade {learning_outcome['grade_level']} (ages {learning_outcome['grade_level'] + 5}-{learning_outcome['grade_level'] + 6})
Learning Outcome: {learning_outcome['outcome_text']}
Topic Area: {learning_outcome['topic_area']}
Bloom's Cognitive Level: {learning_outcome['bloom_level']}
Target Difficulty: {target_difficulty}/5.0
"""

        # Constraints
        constraints = """
CONSTRAINTS:
1. Use simple vocabulary appropriate for the target grade level
2. Keep question stem to 10-25 words maximum
3. Keep answer choices to 3-15 words each
4. Generate exactly three plausible but incorrect distractors
5. Include Qatar-relevant examples where appropriate (e.g., Qatar websites, local contexts)
6. Avoid stereotypes, cultural insensitivity, or exclusionary language
7. Ensure distractors reflect common misconceptions or partial understanding
8. Provide a clear explanation (20-100 words) suitable for student feedback
"""

        # Few-shot examples
        examples_text = "\n\n".join([
            f"EXAMPLE {i + 1}:\nLearning Outcome: {ex['learning_outcome']}\nGrade: {ex['grade_level']}\n\nGenerated Question:\n{json.dumps(ex['question'], indent=2)}"
            for i, ex in enumerate(self.exemplars[:2])  # Use 2 examples to keep prompt manageable
        ])

        # Task specification
        task = f"""
Now generate a {learning_outcome['bloom_level']}-level multiple-choice question for the following:

Learning Outcome: {learning_outcome['outcome_text']}
Grade Level: {learning_outcome['grade_level']}
Target Difficulty: {target_difficulty}/5.0

OUTPUT FORMAT (JSON):
{self.output_parser.get_format_instructions()}

Generate the question now:
"""

        # Combine all components
        full_prompt = f"{system_message}\n\n{context}\n\n{constraints}\n\n{examples_text}\n\n{task}"

        return full_prompt

    def _validate_question(self, question: QuestionSchema,
                           learning_outcome: Dict) -> bool:
        """
        Apply additional validation checks beyond schema validation.
        """
        # Check Bloom's level matches
        if question.bloom_level != learning_outcome['bloom_level']:
            return False

        # Check for keyword presence (curriculum alignment indicator)
        outcome_keywords = set(learning_outcome.get('keywords', []))
        question_text = (question.question_stem + " " +
                         question.correct_answer + " " +
                         " ".join(question.distractors)).lower()

        keyword_matches = sum(1 for kw in outcome_keywords if kw in question_text)
        if keyword_matches == 0:
            return False  # No curriculum keywords present

        # Check distractor uniqueness
        all_choices = [question.correct_answer] + question.distractors
        if len(set(all_choices)) != 4:
            return False  # Duplicate answer choices

        # Check readability appropriate for grade level
        fk_grade = textstat.textstat.flesch_kincaid_grade(question.question_stem)
        if fk_grade > learning_outcome["grade_level"] + 2:
            return False  # Reading level too high

        return True

    def _adjust_prompt_for_retry(self, original_prompt: str,
                                 attempt: int) -> str:
        """Adjust prompt for retry attempts to improve success rate."""
        adjustments = [
            "\n\nIMPORTANT: Ensure the question uses simple vocabulary suitable for young children.",
            "\n\nIMPORTANT: Make sure distractors are plausible and similar in length to the correct answer.",
            "\n\nIMPORTANT: Include at least one keyword from the learning outcome in the question."
        ]

        if attempt < len(adjustments):
            return original_prompt + adjustments[attempt]
        return original_prompt

    def batch_generate(self, learning_outcomes: List[Dict],
                       questions_per_outcome: int = 5) -> List[Dict]:
        """
        Generate multiple questions for each learning outcome.

        Args:
            learning_outcomes: List of learning outcome dictionaries
            questions_per_outcome: Number of questions to generate per outcome

        Returns:
            List of generated questions with metadata
        """
        all_questions = []

        for outcome in learning_outcomes:
            print(f"Generating questions for: {outcome['outcome_text'][:50]}...")

            # Generate questions at varying difficulty levels
            difficulties = [1.0, 2.0, 3.0, 4.0, 5.0][:questions_per_outcome]

            for difficulty in difficulties:
                question = self.generate_question(outcome, difficulty)

                if question:
                    # Add metadata
                    question['learning_outcome_id'] = outcome.get('id')
                    question['curriculum_id'] = outcome.get('curriculum_id')
                    question['topic_area'] = outcome.get('topic_area')
                    question['grade_level'] = outcome.get('grade_level')

                    all_questions.append(question)
                else:
                    print(f"  Failed to generate question at difficulty {difficulty}")

        return all_questions
